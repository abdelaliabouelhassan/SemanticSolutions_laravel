


<?php $__env->startSection('content'); ?>


<first-section ></first-section>
<second-section ></second-section>
<third-section ></third-section>
<fourth-section ></fourth-section>
<fifth-section ></fifth-section>
<sixth-section ></sixth-section>
<seventh-section ></seventh-section>
<eighth-section ></eighth-section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SemanticSolutions_laravel\resources\views/home.blade.php ENDPATH**/ ?>