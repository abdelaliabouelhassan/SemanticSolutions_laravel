


<?php $__env->startSection('content'); ?>

<app-datenschutz></app-datenschutz> 



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SemanticSolutions_laravel\resources\views/datenschutz.blade.php ENDPATH**/ ?>