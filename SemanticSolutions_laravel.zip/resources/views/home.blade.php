@extends('layouts.app')


@section('content')


<first-section ></first-section>
<second-section ></second-section>
<third-section ></third-section>
<fourth-section ></fourth-section>
<fifth-section ></fifth-section>
<sixth-section ></sixth-section>
<seventh-section ></seventh-section>
<eighth-section ></eighth-section>



@endsection