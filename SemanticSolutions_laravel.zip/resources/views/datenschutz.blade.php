@extends('layouts.app')


@section('content')

<app-datenschutz></app-datenschutz> 



@endsection