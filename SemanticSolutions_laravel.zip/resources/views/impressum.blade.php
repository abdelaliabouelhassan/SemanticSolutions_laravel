@extends('layouts.app')


@section('content')

<app-impressum></app-impressum> 



@endsection