<template>
    <section class=" w-full relative py-40 overflow-hidden" id="Leistungen">
         <div class="md:max-w-[200px] max-w-[180px] lg:max-w-[440px] 2xl:max-w-[670px] z-20  w-full vt h-0.5 bg-secondary absolute bottom-0 left-0 md:left-auto md:right-0  "></div>
         <div class=" w-full md:max-w-[758px] xl:max-w-[1200px] m-auto  px-4 flex md:flex-row flex-col space-y-10 md:space-y-0 items-center xl:items-end space-x-20 relative z-20">
            <div class=" w-full flex flex-col items-start space-y-5 xl:space-y-20 max-w-[351px] xl:max-w-[448px]">
                <div class=" w-full  flex flex-col ">
                    <div class=" w-full flex flex-col items-start space-y-2 xl:space-y-4">
                        <p class=" text-primary text-[28px] xl:text-[35px] font-bold font-inter">
                            Unsere <span class=" text-secondary">Leistung</span>
                        </p>
                        <p class=" text-[15px] xl:text-[18px] font-inter font-light leading-[18.15px] xl:leading-[21.78px] text-primary">
                            Mit unserer Social-Recruiting-Methode helfen wir dir deinen offenen Stellen strategisch und planbar zu besetzen. Von der Definierung deines Wunschbewerbers bis zur maßgeschneiderten Kampagne. Sag ‚Adieu!‘ zu deinen Vakanzkosten.
                        </p>
                    </div>
                </div>
                <div class=" w-full grid grid-cols-2 gap-5">
                    <div class=" flex flex-col items-start xl:space-y-2">
                        <span class=" text-primary text-[18px] xl:text-[27px] font-bold font-inter">100%</span>
                        <p class=" text-[15px] xl:text-[18px]  leading-[18.15px] xl:leading-[21.78px] font-inter font-light text-primary max-w-[133px]">
                            Der Kandidaten 
                            erreichen
                        </p>
                    </div>
                     <div class=" flex flex-col items-start xl:space-y-2">
                        <span class=" text-primary text-[18px] xl:text-[27px] font-bold font-inter">2,5 x</span>
                        <p class=" text-[15px] xl:text-[18px]  leading-[18.15px] xl:leading-[21.78px] font-inter font-light text-primary max-w-[133px]">
                            Mehr Bewerber als konventionelle Methoden
                        </p>
                    </div>
                     <div class=" flex flex-col items-start xl:space-y-2">
                        <span class=" text-primary text-[18px] xl:text-[27px] font-bold font-inter">50 %</span>
                        <p class=" text-[15px] xl:text-[18px]  leading-[18.15px] xl:leading-[21.78px] font-inter font-light text-primary max-w-[133px]">
                            Geringere  <br>
                            Cost-Per-Hire Kosten
                        </p>
                    </div>
                     <div class=" flex flex-col items-start xl:space-y-2">
                        <span class=" text-primary text-[18px] xl:text-[27px] font-bold font-inter">100 %</span>
                        <p class=" text-[15px] xl:text-[18px]  leading-[18.15px] xl:leading-[21.78px] font-inter font-light text-primary max-w-[133px]">
                            Stressfrei
                        </p>
                    </div>
                </div>
            </div>
            <div class=" w-full flex flex-col items-center space-y-4 -space-x-14 max-w-[400px] md:max-w-full">
                <div class=" grid-cols-1 xl:grid-cols-2 space-y-4  space-x-10 xl:space-x-2 xl:space-y-0 grid w-full">
                    <div class=" w-full card py-5 xl:py-7  space-y-4 max-w-[244px] md:max-w-[300px] xl:max-w-[325px]">
                        <div class=" h-[2px] max-w-[150px] w-full bg-secondary"></div>
                        <div class=" flex flex-col  px-4 w-full">
                            <span class=" text-[15px] xl:text-[24px] text-tertiary font-bold font-inter whitespace-nowrap">Personalisierte Werbung</span>
                            <p class=" text-[15px] leading-[18.15px] xl:text-[18px] xl:leading-[21.78px] text-tertiary font-light font-inter max-w-[226px] md:max-w-[277px] xl:max-w-[293px]">
                            Durch maßgeschneiderte Kommunikation drücken wir bei deinem Wunschbewerber genau die richtigen Knöpfe.
                            </p>
                        </div>
                    </div>
                    <div class=" w-full card py-5 xl:py-7 space-y-4  max-w-[244px] md:max-w-[300px] xl:max-w-[325px]">
                        <div class=" h-[2px] max-w-[150px] w-full bg-secondary"></div>
                        <div class=" flex flex-col  px-4 w-full">
                            <span class=" text-[15px] xl:text-[24px] text-tertiary font-bold font-inter whitespace-nowrap">Agile Werbekampagnen</span>
                            <p class=" text-[15px] leading-[18.15px] xl:text-[18px] xl:leading-[21.78px] text-tertiary font-light font-inter max-w-[218px] md:max-w-[268px] xl:max-w-[286px]">
                              Mit unserer Relevanzoptimierung bauen wir effiziente und zielgruppennahe Kampagnen für deinen Wunschkandidaten.  
                            </p>
                        </div>
                    </div>
                
                </div>
                <div class="  grid-cols-1 xl:grid-cols-2 space-y-4  space-x-10 xl:space-x-2 xl:space-y-0 grid w-full">
                    <div class=" w-full card py-5 xl:py-7 space-y-4  max-w-[244px] md:max-w-[300px] xl:max-w-[325px]">
                        <div class=" h-[2px] max-w-[150px] w-full bg-secondary"></div>
                        <div class=" flex flex-col  px-4 w-full">
                            <span class=" text-[15px] xl:text-[24px] text-tertiary font-bold font-inter whitespace-nowrap">KI-gestützte Anzeigen</span>
                            <p class=" text-[15px] leading-[18.15px] xl:text-[18px] xl:leading-[21.78px] text-tertiary font-light font-inter max-w-[222px] md:max-w-[273px] xl:max-w-[291px]">
                                Anhand von demographischen Merkmalen und Interessen wird dein Wunschkandidat mithilfe seines digitalen Fingerabdrucks gefunden.
                            </p>
                        </div>
                    </div>
                    <div class=" w-full card py-5 xl:py-7 space-y-4  max-w-[244px] md:max-w-[300px] xl:max-w-[325px]">
                        <div class=" h-[2px] max-w-[150px] w-full bg-secondary"></div>
                        <div class=" flex flex-col  px-4 w-full">
                            <span class=" text-[15px] xl:text-[24px] text-tertiary font-bold font-inter whitespace-nowrap">Digital Storytelling</span>
                            <p class=" text-[15px] leading-[18.15px] xl:text-[18px] xl:leading-[21.78px] text-tertiary font-light font-inter max-w-[223px] md:max-w-[274px] xl:max-w-[292px]">
                               Egal ob Text, Bild oder Video: Wir liefern qualitativen Content, der aus der Masse hervorsticht. Unser Storyscaping bindet deinen Wunschbewerber an deine Marke.
                            </p>
                        </div>
                    </div>
                
                </div>
            </div>
         </div>
         <div class=" ">
            <img src="../assets/Polygonright.png" class=" w-full h-full absolute bottom-0 left-0 max-h-[261px] hidden md:block" alt="">
            <img src="../assets/Polygonrightbottom.png" class=" w-full h-full absolute top-0 left-0 max-h-[280px] md:max-h-[300px] xl:max-h-[531px] md:hidden" alt="">
        </div>
    </section>
</template>