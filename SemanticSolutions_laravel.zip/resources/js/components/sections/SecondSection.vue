<template>
    <section class=" w-full md:max-w-[758px] lg:max-w-[1150px] m-auto py-28 px-4" id="Wiesowir">
        <div class=" w-full flex flex-col items-center space-y-20">
            <div class=" flex flex-col items-center space-y-4 w-full">
                <div class=" flex flex-col items-center lg:-space-y-4 md:-space-y-2 -space-y-1 text-[24px] md:text-[28px] lg:text-[35px] font-bold font-inter">
                    <span class=" text-primary">Social-Recruiting</span>
                    <span class=" text-secondary">ohne Schnickschnack</span>
                </div>
                <p class=" w-full max-w-[250px] md:max-w-[442px] lg:max-w-[530px] lg:text-[18px] text-[15px] font-light text-primary font-inter text-center leading-[18.5px]  lg:leading-[21.78px]">
                   Stellen ausschreiben kann jeder! Wir bringen Wunschbewerber.
                    Einfach. Ehrlich. Effektiv.
                </p>
            </div>

            <div class=" w-full grid grid-cols-1 sm:grid-cols-3 gap-10 lg:gap-28  max-w-[250px]  sm:max-w-max m-auto">
                <div class=" w-full card pt-7 pb-7 lg:pb-12 space-y-2 max-w-[250px] md:max-w-[200px] lg:max-w-[299px]">
                    <div class=" h-[2px] max-w-[150px] w-full bg-secondary"></div>
                    <div class=" flex flex-col space-y-2 px-5">
                        <span class=" text-[18px] lg:text-[27px] text-tertiary font-bold font-inter">Persönlich</span>
                        <p class=" text-[15px] leading-[18.15px] lg:text-[18px] lg:leading-[21.78px] text-tertiary font-light font-inter max-w-[242px]">
                            Durch unsere individuellen Lösungen hebt sich dein Unternehmen klar im Arbeitgebermarkt ab.
                        </p>
                    </div>
                </div>
                 <div class=" w-full card pt-7 pb-7 lg:pb-12 space-y-2 max-w-[250px] md:max-w-[200px] lg:max-w-[299px]">
                    <div class=" h-[2px] max-w-[150px] w-full bg-secondary"></div>
                    <div class=" flex flex-col space-y-2 px-5">
                        <span class=" text-[18px] lg:text-[27px] text-tertiary font-bold font-inter">Data Driven</span>
                        <p class=" text-[15px] leading-[18.15px] lg:text-[18px] lg:leading-[21.78px] text-tertiary font-light font-inter max-w-[242px]">
                           Zahlen lügen nicht! optimierte Kampangen machen dein Unternehmen für Kandidaten sichtbar.
                        </p>
                    </div>
                </div>
                 <div class=" w-full card pt-7 pb-7 lg:pb-12 space-y-2max-w-[250px] md:max-w-[200px] lg:max-w-[299px]">
                    <div class=" h-[2px] max-w-[150px] w-full bg-secondary"></div>
                    <div class=" flex flex-col space-y-2 px-5">
                        <span class=" text-[18px] lg:text-[27px] text-tertiary font-bold font-inter">Social Natives</span>
                        <p class=" text-[15px] leading-[18.15px] lg:text-[18px] lg:leading-[21.78px] text-tertiary font-light font-inter max-w-[242px]">
                            Soziale Netzwerke sind unser gewohntes Spielfeld. Zielgerichtete Züge bringen prägnante Ergebnisse. 
                        </p>
                    </div>
                </div>
               
            </div>
        </div>
    </section>
</template>