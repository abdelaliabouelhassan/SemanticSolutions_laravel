<template>
   <section class=" w-full relative ">
        <div class=" w-full md:max-w-[758px] lg:max-w-[1150px] m-auto py-36 px-4 z-20 relative">
            <div class=" w-full flex flex-col items-center space-y-8 md:space-y-16 lg:space-y-28">
            <p class=" text-[24px] text-center md:text-[28px] lg:text-[35px] font-bold font-inter text-primary">
                Mit uns bis zu 75 % mehr <span class=" text-secondary"> Bewerber erreichen</span>
            </p>

            <div class=" w-full flex md:flex-row flex-col space-y-10 md:space-y-0 items-center lg:items-end md:space-x-5 lg:space-x-28 xl:space-x-36">
                <div class=" max-w-[318.84px] md:max-w-[543px] lg:max-w-[670px] w-full">
                    <img src="../assets/bewerber.png" class=" w-full h-full z-20 relative" alt="">
                </div>
                <div class=" max-w-[303px] md:max-w-[323px] lg:max-w-[458px]">
                    <p class=" text-[15px] lg:text-[18px] font-inter leading-[18.5px] lg:leading-[21.78px] text-primary font-light z-20 relative">
                        Nur 20% der Kandidaten im Markt bewerben sich aktiv bei Unternehmen.
                        <br> <br>
                        Der Großteil sind passive Bewerber, sie befinden sich im sogenannten „Niemannsland“, sind unzufrieden mit ihrer Situation aber entscheiden sich nicht dazu aktiv nach neuen Möglichkeiten zu suchen. Zu groß ist ihre Angst vor dem Ungewissen.
                        <br> <br>
                        Natürlich gibt es auch passive Bewerber die zufrieden  mit ihrer jetzigen beruflichen Situation und dennoch offen für etwas neues sind.
                        <br> <br>
                        Durch unsere Social-Recruiting-Methode wird der Bewerbungsprozess simplifiziert. Profitiere davon, dass du genau diese Bewerber erreichst
                    </p>
                </div>
            </div>
            
            </div>
        </div>
        <div class="md:max-w-[200px] max-w-[180px] lg:max-w-[440px] 2xl:max-w-[670px] z-20  w-full vt h-0.5 bg-secondary absolute bottom-0 right-0 md:left-0 "></div>
        <div class=" xl:pt-32">
            <img src="../assets/Polygonleft.png" class=" w-full h-full absolute bottom-0 left-0 md:max-h-[300px] xl:max-h-[531px] hidden md:block" alt="">
            <img src="../assets/Polygonbottom.png" class=" w-full h-full absolute top-0 left-0 max-h-[280px] md:max-h-[300px] xl:max-h-[531px] md:hidden" alt="">
        </div>
   </section>
</template>