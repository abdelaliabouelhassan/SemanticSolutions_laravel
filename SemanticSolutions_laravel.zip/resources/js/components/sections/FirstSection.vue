<template>
    <div class=" w-full px-4 h-screen">
        <div class="md:max-w-[758px] lg:max-w-[1150px] m-auto pt-56">
            <div class=" w-full flex flex-col items-start space-y-4 max-w-[231px] md:max-w-[282px] lg:max-w-[364px] z-20 relative">
                <div class=" border-b-[2px] border-secondary w-full">
                        <div class=" space-x-2 text-[24px] md:text-[28px] lg:text-[35px] font-bold font-inter">
                            <span class=" text-primary">Semantic</span>
                            <span class=" text-secondary">Solutions</span>
                        </div>
                </div>
                <p class=" text-primary text-[17px] md:text-[18px] lg:text-[27px] font-inter font-light leading-[21px] md:leading-[22px] lg:leading-[33px]">
                    Wunschbewerber finden.
                    Vakanzkosten ‚Adieu!‘ sagen.
                </p>
            </div>
        </div>
        <div class="  w-full">
            <img src="../assets/firstsection.png" class=" w-full max-w-[1500px] absolute right-0 bottom-0 z-0" alt="">
            <div class=" absolute right-0 bottom-0 h-[2px] bg-secondary max-w-[200px] lg:max-w-[440px] 2xl:max-w-[670px] w-full vt "></div>
        </div>
    </div>
</template>