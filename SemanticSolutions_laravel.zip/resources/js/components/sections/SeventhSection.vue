<template>
    <section class=" w-full relative py-48 overflow-hidden" id="Dassindwir">
         <div class="md:max-w-[200px] max-w-[180px] lg:max-w-[440px] 2xl:max-w-[670px] z-20  w-full vt h-0.5 bg-secondary absolute bottom-0 right-0  "></div>
         <div class=" w-full md:max-w-[758px] lg:max-w-[1210px] m-auto  px-4 flex md:flex-row flex-col space-y-10 md:space-y-0 items-center xl:items-end space-x-20 relative z-20">
            <div class=" flex items-center md:flex-row flex-col space-y-5 md:space-y-0  md:space-x-5 lg:space-x-14 w-full">
                <div class=" max-w-[306px] md:max-w-[328px] lg:max-w-[484px]">
                    <span class=" text-primary font-bold font-inter text-[28px] lg:text-[35px]">Das sind <span class=" text-secondary">wir</span></span>
                    <p class=" text-primary font-normal text-[15px] lg:text-[18px] leading-[18.15px] lg:leading-[21.78px] font-inter">
                        Wir sind Semaso.
                        <br> <br>
                        Semaso steht für <span class=" font-bold">Semantic Solutions</span> – Lösungen mit Bedeutung. 
                        <br> <br>
                        Seit 2018 entwerfen wir Marken, entwickeln Webauftritte und planen Marketing-Konzepte. 5 Jahre Branding, Performance-Marketing und Webdesign resultieren in einer Entwicklung von Social-Natives zu Young Professionals.
                        <br> <br>
                        Uns ist aufgefallen, dass die meisten Marketingagenturen im deutschen Markt standartisierte, baukastenartige Ergebnisse liefern. Statt Massenabfertigung, kreieren wir mit Herz und Leidenschaft Lösungen mit Bedeutung.
                    </p>
                </div>
                <div class=" max-w-[298px] max-h-[169px] md:max-w-[406px] md:max-h-[230px] w-full h-full lg:max-w-[618px] lg:max-h-[350px]">
                    <img src="../assets/Semaso.png" class=" w-full h-full" alt="">
                </div>
            </div>
         </div>
        <div class=" ">
            <img src="../assets/Polygonright.png" class=" w-full h-full absolute bottom-0 left-0 max-h-[261px] " alt="">
            <img src="../assets/Polygonrightbottom.png" class=" w-full h-full absolute top-0 left-0 max-h-[280px] md:max-h-[300px] xl:max-h-[531px] md:hidden" alt="">
        </div>
        
    </section>
</template>

