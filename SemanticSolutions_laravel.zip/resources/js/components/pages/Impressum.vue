<template>
    <div class=" w-full">
    <div class=" w-full md:max-w-[758px] lg:max-w-[1150px] m-auto py-28 px-4 space-y-24">
        <div>
            <span class=" font-bold font-inter text-[35px] text-black border-b-[2px] border-secondary pb-3">Impressum</span>
        </div>

        <div class=" w-full flex flex-col items-start space-y-10">
          <div class=" flex flex-col items-start space-y-2">
              <span class=" text-primary font-bold text-[28px] font-inter">Semantic Solutions</span>
              <p class=" w-full">
                Baker, Jakob, Klingelhöffer & Landau GbR <br>
                Klappacherstraße 97 <br>
                64285 Darmstadt
                <br><br>
                info@semaso.de <br> 015902671977
                <br><br><br>
                 <span class=" text-primary font-bold  font-inter"> Vertretungsberechtigte Gesellschafter:</span>
                <br> Marvin Baker <br> Patrick Jakob <br> Lorenz Klingelhöffer <br> Florian Landau
                 <br><br><br>
                Link auf die Plattform der EU-Kommission zur Online-Streitbeilegung: https://ec.europa.eu/consumers/odr
                <br><br>
                Zur Teilnahme an einem Streitbeilegungsverfahren vor einer Verbraucherschlichtungsstelle sind wir nicht <br> verpflichtet und grundsätzlich nicht bereit.
                <br><br>
                Attributionen: <br> <a href="https://storyset.com/nature" class=" text-secondary" >Iceberg Illustration by Storyset</a>
              </p>
          </div>
          <p>
          










          </p>
        </div>
    </div>
</div>
</template>